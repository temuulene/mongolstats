utils::globalVariables(c(
  "TBL_ID","Indicator_RN","Period","PERIOD","CODE","CODE1","CODE2",
  "SCR_MN","SCR_ENG","SCR_MN1","SCR_ENG1","SCR_MN2","SCR_ENG2",
  "DTVAL_CO"
))

