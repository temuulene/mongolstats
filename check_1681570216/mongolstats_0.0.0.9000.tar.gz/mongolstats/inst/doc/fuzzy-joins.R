## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# library(sf)

## -----------------------------------------------------------------------------
# adm1 <- mn_boundaries("ADM1") %>% mn_boundaries_normalize()
# 
# # Create a small example with slightly altered names
# sample_names <- head(adm1$shapeName, 6)
# altered <- sub("a", "", sample_names) # remove one 'a' to simulate typos
# dat <- tibble::tibble(name = altered, value = seq_along(altered))
# 
# # Fuzzy join (max distance 2)
# joined <- mn_fuzzy_join_by_name(dat, name_col = "name", level = "ADM1", boundaries = adm1, max_distance = 2)
# joined %>% select(shapeName, name, value) %>% head()

