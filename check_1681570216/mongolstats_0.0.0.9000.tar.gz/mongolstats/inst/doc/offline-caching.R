## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
}
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)

## -----------------------------------------------------------------------------
# dir <- tryCatch(nso_cache_enable(ttl = 7 * 24 * 3600), error = function(e) NULL)
# dir

## -----------------------------------------------------------------------------
# nso_cache_status()

## -----------------------------------------------------------------------------
# nso_offline_enable()
# 
# # This will use cache if available; otherwise it will error due to offline mode
# itms <- try(nso_itms(), silent = TRUE)
# itms
# 
# nso_offline_disable()

