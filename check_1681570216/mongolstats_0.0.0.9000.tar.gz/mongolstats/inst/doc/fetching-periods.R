## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)

## -----------------------------------------------------------------------------
# # Monthly sequence
# nso_period_seq("201801", "201812", by = "M")
# 
# # Yearly sequence
# nso_period_seq("2018", "2022", by = "Y")

## -----------------------------------------------------------------------------
# tbl <- "DT_NSO_0300_001V2"
# periods <- nso_table_periods(tbl)
# head(periods)
# tail(periods)

## -----------------------------------------------------------------------------
# dat <- nso_data(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Sex = "Total", Age = "Total", Year = head(periods, 1)),
#   labels = "en"
# )
# dat %>% dplyr::slice_head(n = 6)

## -----------------------------------------------------------------------------
# yrs <- head(periods, 5)
# series <- nso_data(
#   tbl_id = tbl,
#   selections = list(Sex = "Total", Age = "Total", Year = yrs)
# )
# 
# series %>%
#   dplyr::group_by(Year) %>%
#   dplyr::summarise(value = sum(value, na.rm = TRUE)) %>%
#   dplyr::arrange(Year)

## -----------------------------------------------------------------------------
# trend <- series %>% dplyr::group_by(Year) %>% dplyr::summarise(value = sum(value, na.rm = TRUE))
# if (nrow(trend) > 1) plot(as.numeric(trend$Year), trend$value, type = "b", main = "Total by Year", xlab = "Year", ylab = "Value")

