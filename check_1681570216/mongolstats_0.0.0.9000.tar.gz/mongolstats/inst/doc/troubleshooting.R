## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# nso_options(mongolstats.lang = "en")

## -----------------------------------------------------------------------------
# dims <- nso_dims("DT_NSO_0300_001V2")
# vals_year <- nso_dim_values("DT_NSO_0300_001V2", "Year", labels = "en")
# head(vals_year)

## -----------------------------------------------------------------------------
# q <- nso_query("DT_NSO_0300_001V2", list(Year = "2024", Sex = c("Male","Female"), Age = "Total"))
# dat <- nso_fetch(q, labels = "en")
# head(dat)

## -----------------------------------------------------------------------------
# nso_offline_enable()
# try(nso_sectors())
# nso_offline_disable()

## -----------------------------------------------------------------------------
# options(mongolstats.verbose = TRUE)
# invisible(try(nso_data("DT_NSO_0300_001V2", list(Year = "2024", Sex = "Total", Age = "Total")), silent = TRUE))
# options(mongolstats.verbose = FALSE)

