## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)

## -----------------------------------------------------------------------------
# reqs <- list(
#   list(tbl_id = "DT_NSO_0300_001V2", selections = list(Year = "2024", Sex = "Total", Age = "Total"))
# )
# res <- tryCatch(nso_package(reqs, labels = "code"), error = function(e) NULL)
# res %>% slice_head(n = 5)

## -----------------------------------------------------------------------------
# if (requireNamespace("future", quietly = TRUE) && requireNamespace("future.apply", quietly = TRUE)) {
#   future::plan(future::multisession, workers = 2)
#   res_par <- tryCatch(nso_package(reqs, labels = "code", parallel = TRUE), error = function(e) NULL)
#   future::plan(future::sequential)
# }

## -----------------------------------------------------------------------------
# years <- c("2020","2021","2022","2023","2024")
# chunks <- split(years, ceiling(seq_along(years) / 2))  # chunks of 2
# parts <- lapply(chunks, function(yrs) {
#   nso_data("DT_NSO_0300_001V2", list(Year = yrs, Sex = "Total", Age = "Total"), labels = "code")
# })
# res_chunked <- dplyr::bind_rows(parts)
# res_chunked %>% dplyr::count(Year)

## -----------------------------------------------------------------------------
# options(mongolstats.progress = TRUE)
# res <- tryCatch(nso_package(reqs, labels = "code", parallel = FALSE), error = function(e) NULL)

