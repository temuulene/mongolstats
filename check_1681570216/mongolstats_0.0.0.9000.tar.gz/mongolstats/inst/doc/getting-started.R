## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# 
# # Point to new PXWeb API (default set on load)
# nso_options(mongolstats.lang = "en")

## -----------------------------------------------------------------------------
# itms <- nso_itms()
# itms %>% dplyr::select(dplyr::any_of(c("tbl_id", "tbl_eng_nm", "strt_prd", "end_prd"))) %>% dplyr::slice_head(n = 5)

## -----------------------------------------------------------------------------
# vars <- nso_variables("DT_NSO_0300_001V2")
# vars %>% dplyr::count(field)
# vars %>% dplyr::filter(field %in% c("Sex","Age","Year")) %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# per <- tryCatch(tail(nso_table_periods("DT_NSO_0300_001V2"), 1), error = function(e) "")
# yr <- if (length(per) && nzchar(per[1])) per else "2022"
# dat <- nso_data(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Sex = "Total", Age = "Total", Year = yr)
# )
# 
# dat %>% dplyr::slice_head(n = 6)

## -----------------------------------------------------------------------------
# yr <- tryCatch(tail(nso_table_periods("DT_NSO_0300_001V2"), 1), error = function(e) "2022")
# dat_lbl <- nso_data(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Sex = "Total", Age = "Total", Year = yr)
# )
# 
# dat_code <- nso_data(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Sex = "0", Age = "0", Year = yr)
# )
# 
# list(rows_label = nrow(dat_lbl), rows_code = nrow(dat_code))

## -----------------------------------------------------------------------------
# per <- tryCatch(nso_table_periods("DT_NSO_0300_001V2"), error = function(e) character())
# yrs <- if (length(per) >= 2) tail(per, 2) else per
# if (!length(yrs)) yrs <- c("2021","2022")
# dat_labeled <- nso_data(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Sex = c("Male","Female"), Age = "Total", Year = yrs),
#   labels = "en"
# )
# 
# dat_labeled %>% dplyr::select(dplyr::any_of(c("Year","Sex","value","Year_en","Sex_en"))) %>% dplyr::slice_head(n = 8)

## -----------------------------------------------------------------------------
# periods <- nso_table_periods("DT_NSO_0300_001V2")
# head(periods); tail(periods)
# 
# # Yearly sequence helper
# nso_period_seq("2018","2022", by = "Y")

## -----------------------------------------------------------------------------
# per <- tryCatch(nso_table_periods("DT_NSO_0300_001V2"), error = function(e) character())
# yrs <- if (length(per) >= 5) tail(per, 5) else per
# if (!length(yrs)) yrs <- c("2018","2019","2020","2021","2022")
# dat_year <- nso_data(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Sex = "Total", Age = "Total", Year = yrs)
# )
# 
# dat_year %>%
#   dplyr::group_by(Year) %>%
#   dplyr::summarise(value = sum(value, na.rm = TRUE)) %>%
#   dplyr::arrange(Year) %>%
#   dplyr::slice_head(n = 10)

