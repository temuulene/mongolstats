## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# library(sf)

## -----------------------------------------------------------------------------
# tbl <- "DT_NSO_0300_004V5"  # Resident population by location and region
# 
# # 1) Fetch codebook for the table (PXWeb variables)
# cb  <- nso_variables(tbl)
# unique(cb$field)
# 
# # 2) Inspect items under the likely admin dimension (e.g., 'Region')
# adm_field <- "Region"
# adm_codes <- cb %>% dplyr::filter(field == adm_field) %>% dplyr::select(itm_id, scr_eng)
# head(adm_codes)
# 
# # 3) Build a crosswalk from table codes to boundary keys via name normalization
# adm1 <- mn_boundaries("ADM1") %>% mn_boundaries_normalize()
# adm_codes$name_std <- adm_codes$scr_eng %>% stringr::str_to_lower() %>%
#   stringi::stri_trans_general("Latin-ASCII") %>%
#   stringr::str_replace_all("[^a-z0-9]+", " ") %>% stringr::str_squish()
# 
# cw <- adm_codes %>%
#   dplyr::left_join(
#     dplyr::tibble(shapeName = adm1$shapeName, shapeISO = adm1$shapeISO) %>%
#       dplyr::mutate(name_std = mn_boundaries_normalize(adm1)$name_std),
#     by = "name_std"
#   ) %>%
#   dplyr::select(tbl_code = itm_id, shapeISO, shapeName)
# 
# head(cw)
# 
# periods <- nso_table_periods(tbl)
# dat <- nso_data(tbl, selections = list(Year = tail(periods, 1)), labels = "en")
# 
# # Use the admin field as the key
# col <- adm_field
# if (col %in% names(dat)) dat$tbl_code <- dat[[col]] else dat$tbl_code <- NA_character_
# 
# dat_coded <- dat %>%
#   dplyr::left_join(cw, by = "tbl_code")
# 
# # 5) Join to sf using shapeISO (preferred over names when available)
# adm1_keys <- mn_boundary_keys("ADM1")  # contains shapeISO and name_std
# geo <- mn_boundaries("ADM1") %>% dplyr::left_join(adm1_keys, by = c("shapeISO"))
# 
# joined <- dplyr::left_join(geo, dat_coded, by = "shapeISO")
# plot(joined["value"])  # or use your preferred mapping workflow

