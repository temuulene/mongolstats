## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)

## -----------------------------------------------------------------------------
# reqs <- list(
#   list(tbl_id = "DT_NSO_0300_001V2", selections = list(Sex = "Total", Age = "Total", Year = "2024")),
#   list(tbl_id = "DT_NSO_0300_004V5", selections = list(Year = "2024"))
# )
# reqs

## -----------------------------------------------------------------------------
# pkg <- nso_package(reqs, labels = "en")
# pkg %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# pkg %>%
#   dplyr::group_by(tbl_id) %>%
#   dplyr::summarise(total = sum(value, na.rm = TRUE), n = dplyr::n())

## -----------------------------------------------------------------------------
# req_tbl <- tibble::tibble(
#   tbl_id = c("DT_NSO_0300_001V2","DT_NSO_0300_004V5"),
#   selections = list(
#     list(Sex = "Total", Age = "Total", Year = c("2023","2024")),
#     list(Year = c("2023","2024"))
#   )
# )
# 
# pkg2 <- nso_package(req_tbl, labels = "en")
# pkg2 %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# itms <- nso_tables()
# target <- itms %>% dplyr::filter(stringr::str_detect(stringr::str_to_lower(tbl_eng_nm), "population")) %>% dplyr::slice_head(n = 5)
# target %>% dplyr::select(tbl_id, tbl_eng_nm)

