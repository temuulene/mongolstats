## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# nso_options(mongolstats.lang = "en")

## -----------------------------------------------------------------------------
# itms <- nso_itms()
# itms %>% dplyr::select(tbl_id, tbl_eng_nm, strt_prd, end_prd) %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# root <- nso_sectors()
# root %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# first_id <- if (nrow(root)) root$id[1] else ""
# kids <- nso_subsectors(first_id)
# kids %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# pop <- nso_itms_search("population")
# pop %>% dplyr::select(tbl_id, tbl_eng_nm) %>% dplyr::slice_head(n = 10)

## -----------------------------------------------------------------------------
# vars <- nso_variables("DT_NSO_0300_001V2")
# vars %>% dplyr::count(field)
# vars %>% dplyr::slice_head(n = 10)

