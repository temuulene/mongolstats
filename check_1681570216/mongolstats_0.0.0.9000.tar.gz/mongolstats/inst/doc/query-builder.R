## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# nso_options(mongolstats.lang = "en")

## -----------------------------------------------------------------------------
# dims <- nso_dims("DT_NSO_0300_001V2")
# dims
# 
# nso_dim_values("DT_NSO_0300_001V2", "Year", labels = "en") %>% slice_head(n = 6)

## -----------------------------------------------------------------------------
# yr <- tryCatch(tail(nso_table_periods("DT_NSO_0300_001V2"), 1), error = function(e) "2022")
# q <- nso_query(
#   tbl_id = "DT_NSO_0300_001V2",
#   selections = list(Year = yr, Sex = c("Male","Female"), Age = "Total")
# )
# q

## -----------------------------------------------------------------------------
# dat <- nso_fetch(q, labels = "en")
# dat %>% select(dplyr::any_of(c("Year","Sex","Age","value","Year_en","Sex_en"))) %>% slice_head(n = 8)

