## ----setup, include=FALSE-----------------------------------------------------
eval_site <- TRUE
if (requireNamespace("pkgdown", quietly = TRUE)) eval_site <- pkgdown::in_pkgdown()
if (eval_site && requireNamespace("curl", quietly = TRUE)) eval_site <- curl::has_internet()
knitr::opts_chunk$set(eval = eval_site, message = FALSE, warning = FALSE, error = TRUE)
if (eval_site) {
  options(mongolstats.retry_tries = 5L, mongolstats.timeout = 60)
  try(mongolstats::nso_cache_enable(), silent = TRUE)
}
# Always install local package before knitting to ensure latest API
if (requireNamespace("remotes", quietly = TRUE)) {
  try(remotes::install_local(".", upgrade = "never", force = TRUE, dependencies = FALSE), silent = TRUE)
}

## -----------------------------------------------------------------------------
# library(mongolstats)
# library(dplyr)
# library(sf)

## -----------------------------------------------------------------------------
# adm1 <- mn_boundaries("ADM1") %>% mn_boundaries_normalize()
# head(adm1$name_std)

## -----------------------------------------------------------------------------
# tbl <- "DT_NSO_0300_004V5"  # Resident population by location and region
# 
# periods <- nso_table_periods(tbl)
# dat <- if (length(periods)) nso_data(tbl, selections = list(Year = tail(periods, 1)), labels = "en") else tibble::tibble()
# 
# # Create a name column from the 'Region' dimension if present
# if ("Region_en" %in% names(dat)) dat$name <- dat$Region_en else if ("Region" %in% names(dat)) dat$name <- dat$Region
# 
# joined <- tryCatch(mn_join_by_name(dat, name_col = "name", level = "ADM1"), error = function(e) adm1)

## ----fig.alt="Map of joined ADM1 geometries", fig.cap="ADM1 map joined to example data"----
# plot(sf::st_geometry(joined))

## -----------------------------------------------------------------------------
# keys <- mn_boundary_keys("ADM1")  # contains shapeID, shapeName, shapeISO, name_std
# # Example: if your data has shapeISO, join on that instead of names

## ----fig.alt="Map of Mongolia ADM1 boundaries joined to example values", fig.cap="ADM1 map example"----
# plot(sf::st_geometry(adm1))

