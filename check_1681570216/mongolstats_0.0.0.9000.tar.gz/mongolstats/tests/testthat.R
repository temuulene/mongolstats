library(testthat)
library(mongolstats)

test_check("mongolstats")
